# BRINK CORE — Managed Agents Worker · GO-LIVE

Turns the hub's four stations into your real Claude Console Managed Agents.
~10 minutes if the Console agents already exist.

## 0 · What you need from Claude Console
For each of your five Console agents (Seamus, Ronin, Insect Cop, Polyphemus, Oracle):
- **Agent ID** (`agent_...`) — Console → Agents → open the agent → copy ID
- **Environment ID** (`env_...`) — Console → Environments → the environment each agent runs in

One environment can serve all four; four different ones also fine.

## 1 · Deploy the worker
```bash
# from the folder containing brinkcore-agents-worker.js + brinkcore-agents-wrangler.toml
wrangler kv namespace create BRINK_RUNS
#   → paste the returned id into brinkcore-agents-wrangler.toml (PASTE_KV_ID_HERE)

wrangler secret put ANTHROPIC_API_KEY -c brinkcore-agents-wrangler.toml
wrangler secret put WORKER_KEY -c brinkcore-agents-wrangler.toml   # invent a long random string

wrangler secret put CLAUDE_SEAMUS_AGENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_SEAMUS_ENVIRONMENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_RONIN_AGENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_RONIN_ENVIRONMENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_INSECT_COP_AGENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_INSECT_COP_ENVIRONMENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_POLYPHEMUS_AGENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_POLYPHEMUS_ENVIRONMENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_ORACLE_AGENT_ID -c brinkcore-agents-wrangler.toml
wrangler secret put CLAUDE_ORACLE_ENVIRONMENT_ID -c brinkcore-agents-wrangler.toml

wrangler deploy -c brinkcore-agents-wrangler.toml
#   → note the URL: https://brinkcore-agents.YOUR-SUBDOMAIN.workers.dev
```

Missing an agent's secrets? Fine — that agent reports "Configuration required"; the others run (spec §12).

## 2 · Point the hub at it
Hub (v0.33) → Settings → Credentials Vault → **Managed Agents Backend**:
- Agents Worker URL → the workers.dev URL
- Agents Worker Key → your WORKER_KEY value

Save. The top ticker should now show **Managed Agents backend · Console sessions**;
the bottom issues strip drops the warning.

## 3 · Smoke tests (spec §15 subset)
```bash
# health — config status per agent (§12 admin view)
curl -H "X-Brink-Key: YOUR_WORKER_KEY" https://brinkcore-agents.YOUR-SUBDOMAIN.workers.dev/health

# readiness — read-only, creates nothing (§12 TEST CONNECTION)
curl -X POST -H "X-Brink-Key: YOUR_WORKER_KEY" -H "Content-Type: application/json" \
  -d '{"agentKey":"ronin"}' https://brinkcore-agents.YOUR-SUBDOMAIN.workers.dev/test
```
Then in the hub: type `ronin <paste some code>` → watch states go
STARTING SESSION → AGENT SESSION ACTIVE → DONE, and the report land in AGENT COMMS +
the report store. Run `command review`, select it, confirm — Seamus's Console agent
receives the labeled report.

## Security posture (spec §13)
- Browser sends only allowlisted keys (`seamus/ronin/insect-cop/polyphemus/oracle`) — arbitrary IDs rejected
- All IDs + API key live as worker secrets; poll responses strip `sessionId`
- Shared-key auth on every route · 20 runs/hour rate limit · 120KB body cap
- Secret-pattern redaction on all inbound context (sk-ant-, xi-, ghp_, bearer, key=value)
- Safety conditions block appended server-side to every assignment
- Cancellation: Ctrl+C in the hub archives the live sessions

## Notes
- Costs: Managed Agent sessions bill on session time — treat runs like deploys, not refreshes.
- The hub falls back to direct-call mode automatically if the worker errors — you always get a real answer.
- ElevenLabs stays exactly as built (your call); revisit spec §14 whenever you want it backendized.
